# Revisao de Motion Design - Fini Brasil P2

## Como visualizar

1. Extraia TODO o ZIP para uma pasta no computador. Nao abra apenas o HTML de dentro do ZIP.
2. Abra `revisao-final/index.html` em um navegador atual, como Chrome, Edge ou Firefox.
3. Escolha a sequencia no seletor e clique em Reproduzir.
4. Use Pausar, as setas e a barra de frames para examinar a passagem entre planos.
5. O link abaixo da imagem abre uma folha com amostras e tempos da sequencia.

O pacote funciona offline: os estilos, scripts e dados do visualizador estao embutidos no HTML. Os frames ficam na pasta irma `motion-approved-build/`. Mantenha as duas pastas juntas e nao renomeie os arquivos.

Se o navegador restringir arquivos locais, uma alternativa opcional, para quem ja tem Python instalado, e executar `python -m http.server 8080 --bind 127.0.0.1` na pasta extraida e acessar `http://127.0.0.1:8080/revisao-final/`. Nao e necessario instalar bibliotecas.

## Mapa das sequencias

### Hero

- `1440-hero-1`: Minhocas Azedinhas -> Dentaduras.
- `1440-hero-2`: Dentaduras -> Ursinhos.
- `1440-hero-3`: Ursinhos -> Amoras.
- `1440-hero-4`: Amoras -> Tubes; inclui repouso apos a troca.
- `1440-hero-5`: Tubes -> Minhocas Azedinhas.
- `320-hero-transition`, `375-hero-transition` e `430-hero-transition`: troca Minhocas -> Dentaduras nas larguras mobile indicadas.

### Vibes

- `1440-vibes-azedo`: reacao Azedinho.
- `1440-vibes-doce`: reacao Docinho.
- `1440-vibes-tubes`: reacao Tubes.
- `1440-vibes-classicos`: reacao Classicos.
- `320-vibes-tubes`, `375-vibes-tubes` e `430-vibes-tubes`: transicao para Tubes no mobile.

### Classicos

- `1440-classics-pack-to-display`: embalagem Dentaduras -> display Minhocas.
- `1440-classics-display-to-pack`: display Minhocas -> embalagem Ursinhos.
- `320-classics-transition`, `375-classics-transition` e `430-classics-transition`: troca de embalagem para display no mobile.

### Mundo Fini

- `1440-world-depth`: rolagem desktop para observar a diferenca entre planos de profundidade.
- Nao ha clipe mobile especifico do Mundo Fini neste conjunto: o parallax mobile e estatico por decisao da implementacao.

### Referencia incluida no visualizador final

- `p1-hero-reference`: referencia comparativa de P1, integrante do visualizador final de P2. Esta identificada como referencia e nao representa uma versao intermediaria de P2.

## Conteudo e limites

- Visualizador final completo, sem alteracoes: HTML com scripts e estilos embutidos e 22 folhas de sequencia.
- 22 sequencias e 303 frames usados pelo visualizador, incluindo a referencia P1 explicitamente identificada acima.
- Apenas arquivos de `revisao-final/` e frames referenciados da execucao final `motion-approved-build/`, mais este README.
- Sem backups, perfis de navegador, versoes intermediarias, codigo do site, logs ou dependencias.
- O screencast possui amostragem variavel. O player reproduz os intervalos registrados; nao interpola frames nem comprova 60 fps ou desempenho real.
- Desktop foi testado em 1440 px, com frames limitados a 1100 px de largura na captura. As larguras mobile sao 320, 375 e 430 px.
- As folhas de sequencia sao montagens de frames reais para revisao; nao sao novos assets do site.
- Este pacote permite revisar os registros capturados; nao executa o site interativo.
